/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Grafica;

import java.awt.BasicStroke;
import java.awt.Color;
import java.util.ArrayList;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

/**
 *
 * @author harold
 */
public class Graf {

    public XYSeriesCollection creaDataset(ArrayList<Double> x, ArrayList<Double> y) {

        XYSeries graf = new XYSeries("Série de Gregory-Leibniz");
        for(int i=0; i<x.size();i++){
            graf.add(x.get(i), y.get(i));
        }

        XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(graf);

        return dataset;
    }

    public JFreeChart creaGraf(XYSeriesCollection dataset) {

        JFreeChart xylineChart = ChartFactory.createXYLineChart(
                "Grafica (X,Y)",
                "Número de Terminos",
                "Valor de PI",
                dataset,
                PlotOrientation.VERTICAL, true, true, false);

        XYPlot plot = xylineChart.getXYPlot();

        XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();

        renderer.setSeriesPaint(0, Color.RED);
        renderer.setSeriesStroke(0, new BasicStroke(1.0f));
        plot.setRenderer(renderer);

        return xylineChart;

    }
    
    public void addPunto (double x, double y, XYSeries coord, XYSeriesCollection dataset){
        
        coord.add(x,y);
        dataset.addSeries(coord);
        
    }

}
//Universidad de Cartagena 
//Asignatura: Software libre

//Estudiantes:
//Harold Peña Ramírez
//Jair Calderón Velaídez

//Docente:
//Gabriel Elías Chanchí G.